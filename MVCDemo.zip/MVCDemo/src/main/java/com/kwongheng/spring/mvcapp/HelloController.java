package com.kwongheng.spring.mvcapp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	public HelloController() {
		// TODO Auto-generated constructor stub
		System.out.println("HelloController created");
	}
	@RequestMapping("/hello")
	public ModelAndView method1()
	{
		return new ModelAndView("Page1","msg","Good morning All !!!!!");
	}
	@RequestMapping("/welcome")
	public ModelAndView method2()
	{
		return new ModelAndView("Page2","welcome","welcome all ");
		
	}

}